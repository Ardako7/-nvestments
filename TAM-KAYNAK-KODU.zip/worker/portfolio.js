const portfolioHeaders={'Content-Type':'application/json; charset=utf-8','Cache-Control':'private, no-store','Vary':'oai-authenticated-user-id','X-Content-Type-Options':'nosniff'};
const pjson=(v,status=200)=>new Response(JSON.stringify(v),{status,headers:portfolioHeaders});
async function userKey(id){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(id));return 'private-portfolios/v1/'+Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('')+'.json'}
function cleanPortfolio(body,companies){
 if(typeof body.username!=='string'||!/^[\p{L}\p{N}_. -]{2,30}$/u.test(body.username.trim()))throw Error('Kullanıcı adı 2–30 karakter olmalı.');
 if(!Array.isArray(body.holdings)||body.holdings.length>companies.length)throw Error('Kapsamdaki şirket sayısından fazla hisse eklenemez.');
 const allowed=new Set(companies.map(c=>c.ticker)),seen=new Set();
 const holdings=body.holdings.map(h=>{if(!allowed.has(h.ticker)||seen.has(h.ticker))throw Error('Hisse geçersiz veya tekrar eklenmiş.');seen.add(h.ticker);
 for(const k of ['quantity','cost'])if(typeof h[k]!=='number'||!Number.isFinite(h[k])||h[k]<(k==='quantity'?0.00000001:0)||h[k]>1e9)throw Error('Adet ve maliyet pozitif sayılar olmalı.');
 if(h.currentPrice!==null&&(typeof h.currentPrice!=='number'||!Number.isFinite(h.currentPrice)||h.currentPrice<=0||h.currentPrice>1e9))throw Error('Güncel fiyat geçersiz.');
 return {ticker:h.ticker,quantity:h.quantity,cost:h.cost,currentPrice:h.currentPrice,priceAsOf:h.currentPrice===null?null:new Date().toISOString(),priceSource:h.currentPrice===null?null:'Kullanıcı girişi'};});
 return {username:body.username.trim(),holdings};
}
export async function portfolioAPI(request,env,companies){
 const url=new URL(request.url),id=request.headers.get('oai-authenticated-user-id'),email=request.headers.get('oai-authenticated-user-email');
 if(!id||!email)return pjson({error:'Portföyüne erişmek için giriş yap.',signin:'/signin-with-chatgpt?return_to=%2Fportfoyum%2F'},401);
 if(!env.BUCKET)return pjson({error:'Hesap depolaması geçici olarak kullanılamıyor.'},503);
 if(!['GET','PUT','DELETE'].includes(request.method))return pjson({error:'Desteklenmeyen işlem.'},405);
 if(request.method!=='GET'&&(request.headers.get('Origin')!==url.origin||request.headers.get('X-Arda-Portfolio')!=='1'))return pjson({error:'İşlem kaynağı doğrulanamadı.'},403);
 const key=await userKey(id),obj=await env.BUCKET.get(key),saved=obj?await obj.json():{username:'',holdings:[],revision:0,updatedAt:null};
 if(request.method==='GET'){const reportObject=await env.BUCKET.get(key+'.analysis.json');return pjson({...saved,aiReport:reportObject?await reportObject.json():null,account:{email},aiAvailable:!!env.OPENAI_API_KEY,priceMode:'provider-with-manual-fallback'});}
 try{
 if(Number(request.headers.get('Content-Length')||0)>100000)return pjson({error:'İstek çok büyük.'},413);
 const raw=await request.text();if(raw.length>100000)return pjson({error:'İstek çok büyük.'},413);
 const body=JSON.parse(raw);if(body.revision!==saved.revision)return pjson({error:'Portföy başka bir sekmede değişti. Yeniden yükleyip tekrar dene.'},409);
 const data=request.method==='DELETE'?{username:'',holdings:[]}:cleanPortfolio(body,companies);
 for(const h of data.holdings){const prior=saved.holdings.find(x=>x.ticker===h.ticker);if(prior&&prior.currentPrice===h.currentPrice)h.priceAsOf=prior.priceAsOf;}
 const next={...saved,...data,ledger:request.method==='DELETE'?{events:[],realized:0,flow:0,segment:0,startedAt:null}:pfAdjustment(saved,data),alerts:request.method==='DELETE'?[]:(saved.alerts||[]).filter(a=>data.holdings.some(h=>h.ticker===a.ticker)),revision:saved.revision+1,updatedAt:new Date().toISOString()};
 const result=await env.BUCKET.put(key,JSON.stringify(next),{httpMetadata:{contentType:'application/json'},onlyIf:obj?{etagMatches:obj.etag}:{etagDoesNotMatch:'*'}});
 if(request.method==='DELETE'&&result&&env.BUCKET.delete){await env.BUCKET.delete(key+'.analysis.json');await env.BUCKET.delete(key+'.observations.json');}
 if(!result)return pjson({error:'Aynı anda başka bir kayıt yapıldı. Yeniden yükle.'},409);
 return pjson({...next,account:{email},aiAvailable:!!env.OPENAI_API_KEY,priceMode:'provider-with-manual-fallback'});
 }catch(e){return pjson({error:e instanceof SyntaxError?'İstek biçimi geçersiz.':String(e.message)},400)}
}
