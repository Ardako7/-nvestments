/* Shared, deterministic research controls. No forward estimates or live-price inference. */
(function(root){'use strict';
const finite=n=>typeof n==='number'&&Number.isFinite(n),ratio=(a,b)=>finite(a)&&finite(b)&&b>0?a/b:null;
function research(c){const f=c.financial?.fields||{},v=k=>f[k]?.current,p=k=>f[k]?.previous,bank=/BANKA|SİGORTA|SIGORTA|EMEKLİLİK|EMEKLILIK/i.test(c.industry||''),financial=c.sector==='MALİ KURULUŞLAR',good=[],risks=[],growth=ratio(v('revenue'),p('revenue')),margin=ratio(v('operatingProfit'),v('revenue')),current=bank?null:ratio(v('currentAssets'),v('currentLiabilities')),liability=ratio(v('liabilities'),v('assets')),net=v('parentNetIncome')??v('netIncome');
if(finite(net)){(net>0?good:risks).push(net>0?'Rapordaki altı aylık net sonuç pozitif.':'Rapordaki altı aylık net sonuç sıfır veya negatif.');}
if(growth!==null)(growth>1?good:risks).push('Hasılat, aynı rapordaki karşılaştırmalı altı aylık döneme göre '+(growth>1?'artmış.':'artmamış.'));
if(finite(v('operatingCashFlow')))(v('operatingCashFlow')>0?good:risks).push(v('operatingCashFlow')>0?'İşletme faaliyetleri nakit üretmiş.':'İşletme faaliyetleri nakit tüketmiş veya başa baş kalmış.');
if(finite(v('equity'))&&v('equity')<=0)risks.push('Özkaynak sıfır veya negatif; sermaye yapısı ayrıca incelenmeli.');
if(current!==null&&current<1)risks.push('Cari oran 1’in altında. Vade yapısı ve nakit döngüsü birlikte incelenmeli.');
if(margin!==null&&finite(p('revenue'))&&p('revenue')>0&&finite(p('operatingProfit'))&&margin<p('operatingProfit')/p('revenue'))risks.push('Esas faaliyet marjı karşılaştırmalı dönemin altında.');
if(finite(v('monetaryGain'))&&finite(net)&&Math.abs(v('monetaryGain'))>Math.abs(net))risks.push('Net parasal pozisyon kaleminin büyüklüğü net sonucu aşıyor; faaliyet kârından ayrı okunmalı.');
return {bank,financial,net,growth:growth===null?null:(growth-1)*100,margin:margin===null?null:margin*100,currentRatio:current,liabilityRatio:liability===null?null:liability*100,good,risks};}
function scenario(entry,stop,target,budget){if(![entry,stop,target,budget].every(finite)||entry<=0||stop<=0||stop>=entry||target<=entry||budget<=0)return null;const perShare=entry-stop,quantity=Math.floor(budget/perShare);return {riskReward:(target-entry)/perShare,quantity,position:quantity*entry,risk:quantity*perShare,potential:quantity*(target-entry)};}
root.ArdaBistCore={research,scenario,ratio,finite};if(typeof module!=='undefined')module.exports=root.ArdaBistCore;
})(typeof window!=='undefined'?window:globalThis);
